package com.project.Saving_service;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SavingServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
