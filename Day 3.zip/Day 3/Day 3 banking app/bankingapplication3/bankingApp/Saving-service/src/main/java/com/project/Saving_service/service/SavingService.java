package com.project.Saving_service.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.project.Saving_service.entity.Saving;
import com.project.Saving_service.repo.SavingRepo;



@Service
public class SavingService {

    @Autowired
    private SavingRepo savingRepository;

    public List<Saving> getAllSavings() {
        return savingRepository.findAll();
    }

    public Saving getSavingById(Long id) {
        return savingRepository.findById(id).orElseThrow(() -> new RuntimeException("Saving not found"));
    }

    public List<Saving> getSavingsBySavingNumber(String savingNumber) {
        return savingRepository.findBySavingNumber(savingNumber);
    }

    public Saving createSaving(Saving saving) {
        return savingRepository.save(saving);
    }

    public void deleteSaving(Long id) {
        savingRepository.deleteById(id);
    }
}
