package com.project.Saving_service.repo;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.project.Saving_service.entity.Saving;

@Repository
public interface SavingRepo extends JpaRepository<Saving, Long> {
	List<Saving> findBySavingNumber(String savingNumber);
}
