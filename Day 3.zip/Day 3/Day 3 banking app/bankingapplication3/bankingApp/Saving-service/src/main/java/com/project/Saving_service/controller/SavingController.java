package com.project.Saving_service.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import com.project.Saving_service.entity.Saving;
import com.project.Saving_service.service.SavingService;



@RestController
@RequestMapping("/savings")
public class SavingController {

    @Autowired
    private SavingService savingService;

    @GetMapping
    public List<Saving> getAllSavings() {
        return savingService.getAllSavings();
    }
    
    @GetMapping("/{id}")
    public Saving getSavingById(@PathVariable Long id) {
        return savingService.getSavingById(id);
    }

   
    @GetMapping("/account/{savingNumber}")
    public List<Saving> getSavingsBySavingNumber(@PathVariable String savingNumber) {
        return savingService.getSavingsBySavingNumber(savingNumber);
    }

    @PostMapping
    public Saving createSaving(@RequestBody Saving saving) {
        return savingService.createSaving(saving);
    }

   
    @DeleteMapping("/{id}")
    public void deleteSaving(@PathVariable Long id) {
        savingService.deleteSaving(id);
    }
}
