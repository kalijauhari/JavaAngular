package com.project.Account_service.dto;


import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Data;




public class Savingdto {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String savingNumber;
    private String name;
    private String typeOfSaving;
    private String company;
    private String description;
    private Double amount;
    private String duration;
    private Double interestRate; 
    private Double maturityAmount;

    
    public Savingdto() {}

    public Savingdto(String savingNumber, String name, String typeOfSaving, String company, String description,
                  Double amount, String duration, Double interestRate, Double maturityAmount) {
        this.savingNumber = savingNumber;
        this.name = name;
        this.typeOfSaving = typeOfSaving;
        this.company = company;
        this.description = description;
        this.amount = amount;
        this.duration = duration;
        this.interestRate = interestRate;
        this.maturityAmount = maturityAmount;
    }

    // Getters and Setters
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getSavingNumber() {
        return savingNumber;
    }

    public void setSavingNumber(String savingNumber) {
        this.savingNumber = savingNumber;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getTypeOfSaving() {
        return typeOfSaving;
    }

    public void setTypeOfSaving(String typeOfSaving) {
        this.typeOfSaving = typeOfSaving;
    }

    public String getCompany() {
        return company;
    }

    public void setCompany(String company) {
        this.company = company;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Double getAmount() {
        return amount;
    }

    public void setAmount(Double amount) {
        this.amount = amount;
    }

    public String getDuration() {
        return duration;
    }

    public void setDuration(String duration) {
        this.duration = duration;
    }

    public Double getInterestRate() {
        return interestRate;
    }

    public void setInterestRate(Double interestRate) {
        this.interestRate = interestRate;
    }

    public Double getMaturityAmount() {
        return maturityAmount;
    }

    public void setMaturityAmount(Double maturityAmount) {
        this.maturityAmount = maturityAmount;
    }
}

