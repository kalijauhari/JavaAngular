package com.project.Account_service.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;

import com.project.Account_service.dto.Savingdto;
import com.project.Account_service.entity.Account;
import com.project.Account_service.repo.AccountRepo;

@Service
public class AccountService {
    
    @Autowired
    private AccountRepo accountRepository;
    
    @Autowired
    private WebClient webClient;

    public Account getAccountDetails(Long accountNumber) {
        Account account = accountRepository.findById(accountNumber)
                                           .orElseThrow(() -> new RuntimeException("Account Not Found"));

        List<Savingdto> savings = webClient
            .get()
            .uri("http://localhost:9099/savings/account/" + accountNumber)
            .retrieve()
            .bodyToMono(new ParameterizedTypeReference<List<Savingdto>>() {})
            .block();

        account.setSavings(savings);
        return account;
    }

    public Account createAccount(Account account) {
        return accountRepository.save(account);
    }
}
