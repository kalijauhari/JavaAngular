package com.project.Account_service.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.project.Account_service.entity.Account;

public interface AccountRepo extends JpaRepository<Account, Long>{

}
