package com.project.Account_service.entity;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.project.Account_service.dto.Savingdto;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Transient;
import lombok.Data;

@Data
@Entity
public class Account {
    @Id
    private Long accountNumber;
    private String name;
    private String branch;
    private String ifsc;
    private Double balance;
    
    @JsonProperty(access = JsonProperty.Access.READ_ONLY)
    @Transient
    private List<Savingdto> savings; 

   
}
